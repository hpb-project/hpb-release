﻿####通过如下步骤可以创建基于最新代码的镜像
1.如果想通过git上下载最新的HPB源码，可以通过Dockerfile新建镜像，通过运行如下命令：
	docker build -t ghpb:v1.0.2.3 .
来建立docker镜像。

2.运行如下命令：
	docker save --output ghpb-v1.0.2.3.tar.gz ghpb:v1.0.2.3
来导出镜像，镜像的名称为ghpb，tag为v1.0.2.3。

####如果仅仅是搭建同步节点只要运行如下步骤
1.如果通过已存在的HPB镜像导入后运行；运行如下命令
	docker load < ghpb-v1.0.2.3.tar.gz
来导入镜像。

2.运行如下命令
	docker images
查看镜像文件ghpb:v1.0.2.3是否已经安装好。

3.复制node文件夹到/home/ghpb-bin目录下。

4.运行如下命令
	docker run -it --rm --privileged=true  -v /home/ghpb-bin/node/:/root/node/ --name ghpbinit ghpb:v1.0.2.3 --datadir /root/node/data init /root/node/gensis.json
来初始化创世配置。

5.运行如下命令
	docker run -itd --privileged=true --restart=always -v /home/ghpb-bin/node/:/root/node/ -p 8545:8545 -p 30303:30303 -p 8546:8546 --name ghpb1 ghpb:v1.0.2.3 --datadir /root/node/data --networkid 100 --verbosity 3 --rpc --rpcaddr 0.0.0.0 --rpcapi hpb,web3,admin,txpool,debug,personal,net,miner,prometheus --nodetype synnode console
来启动节点。

6.运行如下命令
	docker attach ghpb1 
可以进入控制台。

7.按下键盘Crl+p+q可以退出当前docker容器控制台。

8.运行如下命令
	docker logs -f ghpb1
可以查看节点的日志





